sudo add-apt-repository ppa:audio-recorder/ppa

