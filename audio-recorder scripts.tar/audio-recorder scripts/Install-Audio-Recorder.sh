sudo apt install audio-recorder

